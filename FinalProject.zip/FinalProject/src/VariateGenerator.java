

public abstract class VariateGenerator    {


    public abstract int nextInt();
    public abstract double nextDouble();



}